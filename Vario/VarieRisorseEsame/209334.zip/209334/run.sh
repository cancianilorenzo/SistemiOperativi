#!/usr/bin/env bash 
first=$1;
second=$2;

make; ./app "${first}" $second 
