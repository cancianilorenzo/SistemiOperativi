#!/usr/bin/env bash 
# subproc.sh

for n in $(seq 1 10); do 
echo $( echo $BASHPID ) - $n
echo $( echo $BASHPID ) - $n
echo $( echo $BASHPID ) - $n
done